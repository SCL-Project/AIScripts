# Scripts
General Scripts for SCL Students

This repository was created by Roman Willi on the 28th of July, 2023. The purpose of this repository is to save scripts that could be beneficial for the SCL project. We encourage students to contribute their valuable scripts to aid others in their development joyyyyyyyyyyyyyyyyyyyyyyyyyy

